///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials() {

	/*
	Used the object material code provided in the OpenGL sample as a reference for the objects.

	Southern New Hampshire University. (n.d.). CS 330 applying lighting to a 3D scene.
	https://learn.snhu.edu/content/enforced/1535995-CS-330-R4851-OL-TRAD-UG.24EW4/course_documents/CS%20330%20Applying%20Lighting%20to%20a%203D%20Scene.pdf?isCourseFile=true&ou=1535995

	*/



	// added the object material for the wood surface
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.20f, 0.35f, 0.15f); 
	woodMaterial.ambientStrength = 0.10f; 
	woodMaterial.diffuseColor = glm::vec3(0.20f, 0.28f, 0.18f);
	woodMaterial.specularColor = glm::vec3(0.5f, 0.15f, 0.1f); 
	woodMaterial.shininess = 0.28; 
	woodMaterial.tag = "wood";

	m_objectMaterials.push_back(woodMaterial);


	// Added the glass object material to act as the material for the mug
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.25f, 0.35f, 0.25f); 
	glassMaterial.ambientStrength = 0.15f; 
	glassMaterial.diffuseColor = glm::vec3(0.20f, 0.35f, 0.32f); 
	glassMaterial.specularColor = glm::vec3(0.3f, 0.50f, 0.40f); 
	glassMaterial.shininess = 35.0; 
	glassMaterial.tag = "glass";

	m_objectMaterials.push_back(glassMaterial);

	// Added the plastic objec to act as a material for computer components
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.ambientColor = glm::vec3(0.05f, 0.05f, 0.05f);  // lower ambient color
	plasticMaterial.ambientStrength = 0.2f; //  higher ambient strength as plastic is slightly more reflective
	plasticMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);  // higher diffuse lighting
	plasticMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);  // plastic material gives off better color for specular lighting
	plasticMaterial.shininess = 25.0f;  // not as shiny as glass material but higher than wood 
	plasticMaterial.tag = "plastic";  

	m_objectMaterials.push_back(plasticMaterial);  


}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting, if no light sources have
	// been added then the display window will be black - to use the 
	// default OpenGL lighting then comment out the following line
	//m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/*** STUDENTS - add the code BELOW for setting up light sources ***/
	/*** Up to four light sources can be defined. Refer to the code ***/
	/*** in the OpenGL Sample for help                              ***/

	// Activate custom lighting - set to true 
	m_pShaderManager->setBoolValue("bUseLighting", true);

	//Make the first light source similar to an indoor lamp - which is closer to the desk than the other light sources
	m_pShaderManager->setVec3Value("lightSources[0].position", 12.0f, 7.0f, 7.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.3f, 0.3f, 0.3f); 
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.3f, 0.25f, 0.2f);  
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.35f, 0.3f, 0.25f); 
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 0.5f); 
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.02f); 


	// Make the second light source similar to ambient outside light
	m_pShaderManager->setVec3Value("lightSources[1].position", 0.0f, 7.0f, -12.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.2f, 0.2f, 0.25f); 
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.2f, 0.2f, 0.2f); 
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 0.8f); 
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.01f);

	// Adding a third and stronger light source to illuminate objects from left side of view.  
	m_pShaderManager->setVec3Value("lightSources[2].position", -14.0f, 7.0f, 8.0f);  
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.3f, 0.3f, 0.3f); 
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.2f, 0.225f, 0.225f); 
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.15f, 0.2f, 0.2f); 
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 0.9f); 
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.03f);


}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/

	bool bReturn = false;

	// texture for mug
	bReturn = CreateGLTexture("textures/Mug Color.jpg", "mug");

	// image for inside mug
	bReturn = CreateGLTexture("textures/Coffee.jpg", "coffee");

	// texture for table
	bReturn = CreateGLTexture("textures/rusticwood.jpg", "wood");

	// texture for computer components
	bReturn = CreateGLTexture("textures/solid black.jpeg", "black");

	// texture for keyboard
	bReturn = CreateGLTexture("textures/abstract black.jpg", "abstract");

	// texture for keyboard
	bReturn = CreateGLTexture("textures/dark.jpg", "dark");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{

	// define the materials for objects in the scene
	DefineObjectMaterials();

	// add and define the light sources for the scene
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	LoadSceneTextures();

	
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadBoxMesh(); // Added the Box mesh
	m_basicMeshes->LoadConeMesh(); // Added the Cone mesh
	m_basicMeshes->LoadCylinderMesh(); // Added the Cylinder mesh
	m_basicMeshes->LoadTorusMesh(); // Load the Torus mesh
	m_basicMeshes->LoadTaperedCylinderMesh(); // Load the tapered cylinder mesh
}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/

 /*
	 Edited by: Dylan Cavazos
 */
void SceneManager::RenderScene() {



	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.96f, 0.94f, 0.88f, 1.0f);
	
	//Set shader texture using rustic coffee texture image
	SetShaderTexture("wood");

	//Set the shader material
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();


	// /****************************************************************/
	/*** //					Renders cylinder for Coffee Mug			****/
	/******************************************************************/
	// Draw the main cylinder body of the mug
	scaleXYZ = glm::vec3(0.75f, 1.0f, 0.50f); // Scale it to the size of a mug

	positionXYZ = glm::vec3(5.75f, 0.01f, 3.0f); // Position it slightly lower to account for the base

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	SetShaderColor(0.98f, 0.96f, 0.94f, 1.0f); // Cream color for the mug

	////SetShaderColor(1, 0, 0, 1);
	// Set the shader texture
	SetShaderTexture("mug");

	////Set the shader material of glass for the sphere mesh
	SetShaderMaterial("glass");

	// Set the textured U, V scale so the image is tiled around the object
	SetTextureUVScale(4.0, 2.0);
	m_basicMeshes->DrawCylinderMesh(false, false, true);

	// Set the shader texture using the coffee image for the mug
	SetShaderTexture("coffee");

	// Not tiled since the image makes sense for this use
	SetTextureUVScale(1.0, 1.0);
	m_basicMeshes->DrawCylinderMesh(true, true, false);

	m_basicMeshes->DrawCylinderMesh();


	// Draw the torus handle
	scaleXYZ = glm::vec3(0.37f, 0.37f, 0.40f); // Scale down the torus for the handle

	positionXYZ = glm::vec3(6.18f, 0.521f, 3.39f); // Adjust position to the right of the mug / Z-Axis -> negative is further back

	SetTransformations(scaleXYZ, 45.0f, 0.0f, -90.0f, positionXYZ); // Rotate to match the cylinder's orientation

	SetShaderColor(0.82f, 0.41f, 0.12f, 1.0f); // Color for the handle

	// Set the shader material of glass for the sphere mesh
	SetShaderMaterial("glass");

	m_basicMeshes->DrawHalfTorusMesh();

	// Draw the torus rim
	scaleXYZ = glm::vec3(0.7f, 0.5f, 0.10f); // Scale it to just be slightly larger than the top of the mug body

	positionXYZ = glm::vec3(5.75f, 1.001f, 3.0f); // Position it on top of the mug

	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ); // Rotate to lay flat on the mug

	SetShaderColor(0.82f, 0.41f, 0.12f, 1.0f); // Same color as the handle

	//Set the shader material of glass for the sphere mesh
	SetShaderMaterial("glass");

	m_basicMeshes->DrawTorusMesh();


	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 5.0f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-18.0f, -5.04f, -6.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();



	// /****************************************************************/
	/*** //					Start of Monitors						****/
	/******************************************************************/

	// /****************************************************************/
	/*** //					Renders box for First Monitor		****/
	/******************************************************************/
	// set the XYZ scale for the monitor mesh
	scaleXYZ = glm::vec3(8.0f, 4.0f, 0.1f); // Aspect ratio might need adjusting

	// set the XYZ rotation for the mesh 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the first monitor mesh
	positionXYZ = glm::vec3(-4.0f, 3.0f, 0.0f);
	
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//  (dark grey)
	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);

	// draw the first monitor 
	m_basicMeshes->DrawBoxMesh();

	// /****************************************************************/
	/*** //					Renders box outline for First Monitor		****/
	/******************************************************************/
	// set the XYZ scale for the monitor mesh
	scaleXYZ = glm::vec3(8.4f, 4.2f, 0.3f); 

	// set the XYZ rotation 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the first monitor mesh
	positionXYZ = glm::vec3(-4.0f, 3.0f, -0.2f);

	// Apply transformations for the first monitor
	SetTransformations(

		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the monitor (dark grey)
	SetShaderColor(0.5f, 0.5f, 0.5f, 1.0f);


	// draw the first monitor with transformation values
	m_basicMeshes->DrawBoxMesh();


	// /****************************************************************/
	/*** //					Renders vertical stand for First Monitor	****/
	/******************************************************************/
	// set the XYZ scale
	scaleXYZ = glm::vec3(0.5f, 1.0f, 0.1f); 

	// set the XYZ rotation for the mesh 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position
	positionXYZ = glm::vec3(-4.0f, 0.5f, 0.0f);

	// Apply transformations for the first monitor
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color 
	SetShaderColor(0.5f, 0.5f, 0.5f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// /****************************************************************/
	/*** //					Renders bottom stand for First Monitor		****/
	/******************************************************************/
	// set the XYZ scale
	scaleXYZ = glm::vec3(1.5f, 0.01f, 0.80f); 

	// set the XYZ rotation for the mesh 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position
	positionXYZ = glm::vec3(-4.0f, 0.05f, 0.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color
	SetShaderColor(0.5f, 0.5f, 0.5f, 1.0f);

	m_basicMeshes->DrawPlaneMesh();


	// /****************************************************************/
	/*** //					Renders box for Second Monitor		****/
	/******************************************************************/
	// set the XYZ scale
	scaleXYZ = glm::vec3(8.0f, 4.0f, 0.1f);

	// set the XYZ rotation 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position
	positionXYZ = glm::vec3(4.5f, 3.0f, 0.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// /****************************************************************/
	/*** //					Renders box outline for Second Monitor		****/
	/******************************************************************/
	// set the XYZ scale
	scaleXYZ = glm::vec3(8.4f, 4.2f, 0.3f); 

	// set the XYZ rotation 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position h
	positionXYZ = glm::vec3(4.5f, 3.0f, -0.2f);

	// Apply transformations 
	SetTransformations(

		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.5f, 0.5f, 0.5f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// /****************************************************************/
	/*** //					Renders vertical stand for Second Monitor	****/
	/******************************************************************/
	// set the XYZ scale 
	scaleXYZ = glm::vec3(0.5f, 1.0f, 0.1f); 

	// set the XYZ rotation 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position 
	positionXYZ = glm::vec3(4.5f, 0.5f, 0.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.5f, 0.5f, 0.5f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// /****************************************************************/
	/*** //					Renders bottom stand for Second Monitor		****/
	/******************************************************************/
	// set the XYZ scale 
	scaleXYZ = glm::vec3(1.5f, 1.0f, 0.80f); 

	// set the XYZ rotation
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position
	positionXYZ = glm::vec3(4.5f, 0.05f, 0.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color 
	SetShaderColor(0.5f, 0.5f, 0.5f, 1.0f);

	m_basicMeshes->DrawPlaneMesh();




	 /****************************************************************/
	/*** //			Beginning of Keyboard structure					***/
	/**						with Keys 								**/
	/******************************************************************/

	// /****************************************************************/
	/*** //						Renders Keyboard					****/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.3f, 0.2f, 1.0f); 

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position 
	positionXYZ = glm::vec3(-0.5f, 0.12f, 5.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color (dark grey)
	/*SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f)*/;

	// sets the shader texture for the monitor
	SetShaderTexture("abstract");

	SetShaderMaterial("plastic");

	m_basicMeshes->DrawBoxMesh();

	// /****************************************************************/
	/*** //						Renders Keyboard Space Key				****/
	/******************************************************************/
	// set the XYZ scale
	scaleXYZ = glm::vec3(1.0f, 0.05f, 0.15f); 

	// set the XYZ rotation
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position 
	positionXYZ = glm::vec3(-0.6f, 0.25f, 5.29f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color
	SetShaderColor(0.3f, 0.3f, 0.3f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// /****************************************************************/
	/*** //				Renders Top Arrow Keyboard Key 				****/
	/******************************************************************/
	// set the XYZ scale 
	scaleXYZ = glm::vec3(0.3f, 0.05f, 0.15f);

	// set the XYZ rotation)
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position
	positionXYZ = glm::vec3(1.15f, 0.25f, 5.10f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	SetShaderColor(0.3f, 0.3f, 0.3f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// /****************************************************************/
/*** //				Renders the Bottom Arrow Keys				****/
/******************************************************************/

	const glm::vec3 scaleXYZ_keys1(0.3f, 0.05f, 0.15f); 
	const float XrotationDegrees_keys1 = 0.0f;          
	const float YrotationDegrees_keys1 = 0.0f;          
	const float ZrotationDegrees_keys1 = 0.0f;          
	const glm::vec4 keyColor1(0.3f, 0.3f, 0.3f, 1.0f);  

	// Starting position for the left arrow key
	glm::vec3 startPosition1(0.80f, 0.25f, 5.29f); 
	float keyOffset1 = 0.35f; 

	// Loop to render the specific keys 
	for (int i = 0; i < 3; ++i) { 
		glm::vec3 position1 = startPosition1 + glm::vec3(i * keyOffset1, 0.0f, 0.0f);

		// Apply transformations 
		SetTransformations(scaleXYZ_keys1, XrotationDegrees_keys1, YrotationDegrees_keys1, ZrotationDegrees_keys1, position1);

		// Set the shader color
		SetShaderColor(keyColor1.r, keyColor1.g, keyColor1.b, keyColor1.a);

		// Draw the key with the transformation values
		m_basicMeshes->DrawBoxMesh();
	}


	// /****************************************************************/
/*** //			Renders one set of Keyboard Top row	Far Right	****/
/******************************************************************/

	const glm::vec3 scaleXYZ_keys2(0.3f, 0.05f, 0.15f); 
	const float XrotationDegrees_keys2 = 0.0f;          
	const float YrotationDegrees_keys2 = 0.0f;          
	const float ZrotationDegrees_keys2 = 0.0f;          
	const glm::vec4 keyColor2(0.3f, 0.3f, 0.3f, 1.0f);  

	
	glm::vec3 startPosition2(0.8f, 0.25f, 4.72f); //  starting position of the first key
	float keyOffset2 = 0.35f;

	// Loop to render the three specific keys
	for (int i = 0; i < 3; ++i) { 
		glm::vec3 position2 = startPosition2 + glm::vec3(i * keyOffset2, 0.0f, 0.0f);

		// Apply transformations
		SetTransformations(scaleXYZ_keys2, XrotationDegrees_keys2, YrotationDegrees_keys2, ZrotationDegrees_keys2, position2);

		// Set the shader color
		SetShaderColor(keyColor2.r, keyColor2.g, keyColor2.b, keyColor2.a);

		// Draw the key with the transformation values
		m_basicMeshes->DrawBoxMesh();
	}


	// /****************************************************************/
/*** //			Renders one set of Keyboard Top row	Far Left	****/
/******************************************************************/

	const glm::vec3 scaleXYZ_keys3(0.3f, 0.05f, 0.15f); 
	const float XrotationDegrees_keys3 = 0.0f;          
	const float YrotationDegrees_keys3 = 0.0f;          
	const float ZrotationDegrees_keys3 = 0.0f;          
	const glm::vec4 keyColor3(0.3f, 0.3f, 0.3f, 1.0f);  

	//  position for the first key in the top row
	glm::vec3 startPosition3(0.10f, 0.25f, 4.72f); 
	float keyOffset3 = -0.35f; 

	// Loop to render the three keys
	for (int i = 0; i < 3; ++i) { 
		glm::vec3 position3 = startPosition3 + glm::vec3(i * keyOffset3, 0.0f, 0.0f);

		// Apply transformationss
		SetTransformations(scaleXYZ_keys3, XrotationDegrees_keys3, YrotationDegrees_keys3, ZrotationDegrees_keys3, position3);

		// Set the shader color
		SetShaderColor(keyColor3.r, keyColor3.g, keyColor3.b, keyColor3.a);

		// Draw the key with the transformation values
		m_basicMeshes->DrawBoxMesh();
	}

	// /****************************************************************/
/*** //			Renders one set of Keyboard Top row	in the Middle	****/
/******************************************************************/
	
	const glm::vec3 scaleXYZ_keys4(0.3f, 0.05f, 0.15f); 
	const float XrotationDegrees_keys4 = 0.0f;          
	const float YrotationDegrees_keys4 = 0.0f;          
	const float ZrotationDegrees_keys4 = 0.0f;          
	const glm::vec4 keyColor4(0.3f, 0.3f, 0.3f, 1.0f);  

	// position for the first of these three keys
	glm::vec3 startPosition4(-1.3f, 0.25f, 4.72f); 
	float keyOffset4 = -0.35f; 

	// Loop to render the three specific keys
	for (int i = 0; i < 3; ++i) { 
		glm::vec3 position4 = startPosition4 + glm::vec3(i * keyOffset4, 0.0f, 0.0f);

		// Apply transformations 
		SetTransformations(scaleXYZ_keys4, XrotationDegrees_keys4, YrotationDegrees_keys4, ZrotationDegrees_keys4, position4);

		// Set the shader color
		SetShaderColor(keyColor4.r, keyColor4.g, keyColor4.b, keyColor4.a);

		// Draw the key with the transformation values
		m_basicMeshes->DrawBoxMesh();
	}


	// /****************************************************************/
/*** //						Renders Keyboard key Top row far left		****/
/******************************************************************/
// set the XYZ scale
	scaleXYZ = glm::vec3(0.3f, 0.05f, 0.15f);

	// set the XYZ rotation 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position 
	positionXYZ = glm::vec3(-2.70f, 0.25f, 4.72f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color
	SetShaderColor(0.3f, 0.3f, 0.3f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// /****************************************************************/
	/*** //	Renders Keyboard Key Bottom Row	to the right of the space key ****/
	/******************************************************************/
	// set the XYZ scale
	scaleXYZ = glm::vec3(0.3f, 0.05f, 0.15f);

	// set the XYZ rotation 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position
	positionXYZ = glm::vec3(0.10f, 0.25f, 5.29f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.3f, 0.3f, 0.3f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// /****************************************************************/
/*** //				Function for adding First row of keys		****/
/******************************************************************/

	const glm::vec3 scaleXYZ_keys5(0.3f, 0.05f, 0.15f); 
	const float XrotationDegrees_keys5 = 0.0f;          
	const float YrotationDegrees_keys5 = 0.0f;          
	const float ZrotationDegrees_keys5 = 0.0f;          
	const glm::vec4 keyColor5(0.3f, 0.3f, 0.3f, 1.0f);  

	// Starting position 
	glm::vec3 startPosition5(-1.3f, 0.25f, 5.29f); 
	float keyOffset5 = -0.35f; 

	// Loop to render the specific keys on the bottom row
	for (int i = 0; i < 5; ++i) { 
		glm::vec3 position5 = startPosition5 + glm::vec3(i * keyOffset5, 0.0f, 0.0f);

		// Apply transformations 
		SetTransformations(scaleXYZ_keys5, XrotationDegrees_keys5, YrotationDegrees_keys5, ZrotationDegrees_keys5, position5);

		// Set the shader color
		SetShaderColor(keyColor5.r, keyColor5.g, keyColor5.b, keyColor5.a);

		// Draw the key with the transformation values
		m_basicMeshes->DrawBoxMesh();
	}


	// /****************************************************************/
/*** //				Function for adding second row of keys		****/
/******************************************************************/

	const glm::vec3 scaleXYZ_keys6(0.3f, 0.05f, 0.15f); 
	const float XrotationDegrees_keys6 = 0.0f;          
	const float YrotationDegrees_keys6 = 0.0f;          
	const float ZrotationDegrees_keys6 = 0.0f;          
	const glm::vec4 keyColor6(0.3f, 0.3f, 0.3f, 1.0f); 

	// add the position for the first key in the second row
	glm::vec3 startPosition6(-2.70f, 0.25f, 5.10f); 
	float keyOffset6 = 0.35f; //  distance between keys

	// Loop to render each key in the second row
	for (int i = 0; i < 9; ++i) { 
		glm::vec3 position6 = startPosition6 + glm::vec3(i * keyOffset6, 0.0f, 0.0f);

		// Apply transformations 
		SetTransformations(scaleXYZ_keys6, XrotationDegrees_keys6, YrotationDegrees_keys6, ZrotationDegrees_keys6, position6);

		// Set the shader color -> red, green, blue, alpha
		SetShaderColor(keyColor6.r, keyColor6.g, keyColor6.b, keyColor6.a);

		// draw the keys with the transformation values
		m_basicMeshes->DrawBoxMesh();
	}


	// /****************************************************************/
/*** //				Function for adding third row of keys		****/
/******************************************************************/

	const glm::vec3 scaleXYZ_keys7(0.3f, 0.05f, 0.15f);
	const float XrotationDegrees_keys7 = 0.0f;
	const float YrotationDegrees_keys7 = 0.0f;
	const float ZrotationDegrees_keys7 = 0.0f;
	const glm::vec4 keyColor7(0.3f, 0.3f, 0.3f, 1.0f); // make the color dark grey

	// add the start position for the first key in the third row
	glm::vec3 startPosition7(-2.70f, 0.25f, 4.91f);
	float keyOffset7 = 0.35f; // the distance between each key

	// add a loop to render each key in third row
	for (int i = 0; i < 9; ++i) {
		glm::vec3 position7 = startPosition7 + glm::vec3(i * keyOffset7, 0.0f, 0.0f);

		// Apply the transformation
		SetTransformations(scaleXYZ_keys7, XrotationDegrees_keys7, YrotationDegrees_keys7, ZrotationDegrees_keys7, position7);

		// set the shader color -> red, green, blue, alpha
		SetShaderColor(keyColor7.r, keyColor7.g, keyColor7.b, keyColor7.a);

		// draw the key with the transformation values
		m_basicMeshes->DrawBoxMesh();

	}


	// /****************************************************************/
/*** //				End of Keyboard Keys							****/
/******************************************************************/




	// /****************************************************************/
/*** //						Renders Keyboard cable				****/
/******************************************************************/
// set the XYZ scale 
	scaleXYZ = glm::vec3(0.05f, 13.5f, 0.05f);

	// set the XYZ rotation 
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position
	positionXYZ = glm::vec3(0.2f, 0.15f, -9.0f);

	// Apply transformations 
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color 
	SetShaderColor(0.3f, 0.3f, 0.3f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	// /****************************************************************/
/*** //						Start of Mouse							****/
/******************************************************************/


// /****************************************************************/
/*** //						Renders Mouse					****/
/******************************************************************/
// set the XYZ scale
	scaleXYZ = glm::vec3(0.35f, 0.2f, 0.35f); 

	// set the XYZ rotation 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position
	positionXYZ = glm::vec3(3.0f, 0.1f, 5.3f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the monitor (dark grey)
	/*SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);*/

	SetShaderTexture("dark");

	m_basicMeshes->DrawSphereMesh();


	// /****************************************************************/
/*** //						Renders Scroll wheel for  mouse					****/
/******************************************************************/
// set the XYZ scale
	scaleXYZ = glm::vec3(0.05f, 0.1f, 0.1f); 

	// set the XYZ rotation
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position
	positionXYZ = glm::vec3(3.0f, 0.23f, 5.2f);

	// Apply transformations 
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the monitor (dark grey)
	/*SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);*/

	SetShaderTexture("dark");

	m_basicMeshes->DrawSphereMesh();


// /****************************************************************/
/*** //						Renders Left Button for Mouse		****/
/******************************************************************/
// set the XYZ scale 
	scaleXYZ = glm::vec3(0.12f, 1.0f, 0.1f); 

	// set the XYZ rotation
	XrotationDegrees = 1.0f;
	YrotationDegrees = 90.0f; // negative angles it downward
	ZrotationDegrees = 25.0f; // positive turns it towards the left. 

	// set the XYZ position 
	positionXYZ = glm::vec3(2.83f, 0.25f, 5.20f); 

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/*SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);*/

	SetShaderTexture("dark");


	// draw with transformation values
	m_basicMeshes->DrawPlaneMesh();

	// /****************************************************************/
	/*** //						Renders Right Button for Mouse					****/
	/******************************************************************/
	// set the XYZ scale for the mouse button mesh
	scaleXYZ = glm::vec3(0.12f, 1.0f, 0.1f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 1.0f;
	YrotationDegrees = 90.0f; // negative angles it downward
	ZrotationDegrees = -15.0f; // positive turns it towards the left. 

	// set the XYZ position 
	positionXYZ = glm::vec3(3.17f, 0.25f, 5.20f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/*SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);*/

	SetShaderTexture("dark");


	// draw with transformation values
	m_basicMeshes->DrawPlaneMesh();

	// /****************************************************************/
/*** //						Start of Headphones						****/
/******************************************************************/

	// /****************************************************************/
/*** //						Renders Headphone Headband					****/
/******************************************************************/

	scaleXYZ = glm::vec3(0.9f, 1.2f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -25.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// set the XYZ position 
	positionXYZ = glm::vec3(-4.0f, 0.5f, 1.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);
	SetShaderTexture("dark");


	// draw with transformation values
	m_basicMeshes->DrawHalfTorusMesh();

	// /****************************************************************/
/*** //						Renders Left Headphone Earbud			****/
/******************************************************************/

	scaleXYZ = glm::vec3(0.25f, 0.4f, 0.35f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -25.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// set the XYZ position 
	positionXYZ = glm::vec3(-4.9f, 0.35f, 1.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	/*SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);*/

	SetShaderTexture("dark");


	// draw with transformation values
	m_basicMeshes->DrawSphereMesh();

	// /****************************************************************/
/*** //						Renders Right Headphone Earbud		****/
/******************************************************************/

	scaleXYZ = glm::vec3(0.3f, 0.4f, 0.35f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -25.0f; 
	YrotationDegrees = 0.0f; 
	ZrotationDegrees = 0.0f; 

	// set the XYZ position 
	positionXYZ = glm::vec3(-3.1f, 0.35f, 1.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);
	SetShaderTexture("dark");

	// draw with transformation values
	m_basicMeshes->DrawSphereMesh();

	// /****************************************************************/
/*** //		Renders Left Outer Ring Headphone Earbud				****/
/******************************************************************/

	scaleXYZ = glm::vec3(0.3f, 0.3f, 0.60f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -05.0f; 
	YrotationDegrees = 90.0f; 
	ZrotationDegrees = 0.0f; 

	// set the XYZ position 
	positionXYZ = glm::vec3(-4.67f, 0.35f, 1.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);
	SetShaderTexture("dark");

	// draw with transformation values
	m_basicMeshes->DrawTorusMesh();

	// /****************************************************************/
/*** //		Renders Right Outer Ring Headphone Earbud				****/
/******************************************************************/

	scaleXYZ = glm::vec3(0.3f, 0.3f, 0.60f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 4.0f; 
	YrotationDegrees = 90.0f; 
	ZrotationDegrees = 0.0f;  

	// set the XYZ position 
	positionXYZ = glm::vec3(-3.3f, 0.35f, 1.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);
	SetShaderTexture("dark");

	// draw with transformation values
	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/
}
